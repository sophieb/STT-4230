# title: "Visualisation de données en R"
# subtitle: "Exercices"
# author: "Sophie Baillargeon"
# date: "25 mai 2017"

# ---- SYSTÈME GRAPHIQUE DE BASE ----

# ---- Exercice 1 : La fonction générique plot ----

### Que fait la fonction plot lorsqu'elle reçoit en entrée un objet de classe lm ?

# Voici un objet de cette classe :
outreg <- lm(stations ~ mag, data = quakes)


### Que fait la fonction plot lorsqu'elle reçoit en entrée un objet de classe ts ?
### (Il s'agit d'une série chronologique.)

# Voici un objet de cette classe :
WWWusage


### Retour à VisualisationR_RaQ2017.pdf


# ---- Exercice 2 : Fonctions de création d'un graphique ----

### Dans le diagramme de dispersion suivant :
plot(x = quakes$mag, y = quakes$stations)
### la majorité des points représentent en fait plusieurs observations.

### La fonction smoothScatter offre une alternative intéressante pour ce genre de données. 
### Reproduisez le diagramme de dispersion précédent avec la fonction smoothScatter.



### Retour à VisualisationR_RaQ2017.pdf



# ---- Exercice 3 : Ajout d'éléments à un graphique et configuration des paramètres ----

### Comment ajouter au diagramme de dispersion initial de la question précédente :
plot(stations ~ mag, data = quakes, col = grey(0.5))

### a) la courbe de régression suivante;
outreg <- lm(stations ~ mag, data = quakes)

### b) la courbe de lissage suivante;
outlowess <- lowess(quakes$mag, quakes$stations)

### c) une légende, en haut à gauche, pour identifier les courbes ajoutées;

### d) le coefficient de détermination de la régression, en bas à droite,
###    avec le libellé "R2 = 0.725", dans lequel le 2 est en exposant ?
R2 <- round(summary(outreg)$r.squared, 3)
R2

### Et comment réduire la dimension de la marge du haut puisqu'on ne désire pas
### que le graphique contienne un titre (ce sera plutôt la figure avec ce graphique,
### dans notre document Word ou LaTeX par exemple, qui aura un titre).



### Retour à VisualisationR_RaQ2017.pdf


# ---- PACKAGE ggplot2 ----

# ---- Exercice 4 : Courbes de densité à noyau superposées ----

# Superposez sur un même graphique deux courbes de densité à noyau :
# - une courbe pour la variable mag de quakes, 
#   seulement pour les observations dans le region "Ouest";
# - une autre courbe pour la même variable, 
#   mais cette fois seulement pour les observations dans le region "Est".



### Retour à VisualisationR_RaQ2017.pdf


# ---- Exercice 5 : Ajout d'éléments à un graphique ----

# Cet exercice est similaire à l'exercice 3, mais on se limite
# aux ajouts a) et b), que l'on modifie un peu pour intégrer
# la variable catégorique région au graphique.

### Produisez un diagramme de dispersion des observations de la variable
### stations en fonction de la variable mag, du jeu de données quakes.
### Les points doivent avoir une couleur différente selon la variable 
### region. Ensuite, ajoutez au diagramme :

### a) la courbe de régression de la variable stations en fonction de la 
###    variable mag (une seule courbe, donc ne pas tenir compte de la 
###    variable région pour cette couche);

### b) deux courbes de lissage par la méthode "loess", soit une
###    pour chaque niveau de la variable region, accompagnées
###    de région de confiance (niveau de confiance par défaut).


### Retour à VisualisationR_RaQ2017.pdf

  